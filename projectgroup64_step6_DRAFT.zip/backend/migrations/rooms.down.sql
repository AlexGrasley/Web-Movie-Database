DROP TABLE `goodmovies`.`rooms`
