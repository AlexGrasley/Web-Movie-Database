DROP TABLE `goodmovies`.`theaters`
