DROP TABLE `goodmovies`.`movies`
