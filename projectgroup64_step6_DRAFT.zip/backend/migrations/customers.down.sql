DROP TABLE `goodmovies`.`customers`
