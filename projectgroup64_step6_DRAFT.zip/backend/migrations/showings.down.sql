DROP TABLE `goodmovies`.`showings`
