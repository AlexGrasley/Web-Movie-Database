DROP TABLE `goodmovies`.`tickets`
