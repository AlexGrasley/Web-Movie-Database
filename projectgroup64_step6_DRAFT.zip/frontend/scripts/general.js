function adjustCols(e){
    $($.fn.dataTable.tables(true)).DataTable()
       .columns.adjust();
 };